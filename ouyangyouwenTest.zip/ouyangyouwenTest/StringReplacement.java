package com.it.ouyanghouse;

public class StringReplacement {
    public String  replaceString() {
        String input = "uaabcccbu";

        return compresString(input);

    }

    private String compresString(String input) {
        //创建循环条件t，当字符串找不到三个相同字母时结束循环
        int t = 1;
        while (t <= 1) {
            input = compressString(input);
            System.out.println(input);
            int cishu = 1;
            int cishu0 = 0;
            for (int i = 0; i < input.length() - 1; i++) {
                if (input.charAt(i) == input.charAt(i + 1)) {
                    cishu++;
                    if (cishu > 2) {
                        cishu0++;
                        break;
                    }
                } else {
                    cishu = 1;
                    cishu0 = 0;
                }
            }
            if (cishu0 == 0) {
                t++;
            }
        }
        System.out.println("最终结果为:" + input);
        return input;
    }

    public  String compressString(String input) {
        StringBuilder compressed = new StringBuilder();
        int count = 1;
        for (int i = 0; i < input.length() - 1; i++) {
            if (input.charAt(i) == input.charAt(i + 1)) {
                count++;
                //如果count>2，则插入当前字母的字母表排位顺序的前一个字母,如果当前字母是'a',则直接删除
                if (count > 2) {
                    if (input.charAt(i) == 'a') {
                        continue;
                    }
                    int figure = input.charAt(i) - 1;
                    char numeric = (char) figure;
                    compressed.append(numeric);
                }
            } else {
                if (count < 3) {
                    for (int j = 0; j < count; j++) {
                        compressed.append(input.charAt(i));
                    }
                }
                count = 1;
            }

        }
        // 处理最后一个字符
        if (count < 3) {
            for (int j = 0; j < count; j++) {
                compressed.append(input.charAt(input.length() - 1));
            }
        }


        return compressed.toString();
    }
}